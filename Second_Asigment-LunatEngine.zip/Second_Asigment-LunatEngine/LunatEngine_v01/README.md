# First-Assignment_LunatEngine
Second game Engine Assigment for the masters degree: Now you theres a duck model loaded.
Github:https://github.com/Lunat12/First-Assignment_LunatEngine.git

    Camera controls:
    While Right-clicking, WASD fps-like movement and free look around must be enabled.
    The mouse wheel should zoom in and out.
    Alt+Left click should orbit the object.
    Pressing “f” should focus the camera on the geometry.
    Holding SHIFT duplicates movement speed.

    Theres a UI on the right side to be able to select the texture filters.
